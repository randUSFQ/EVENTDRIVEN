# ADR-NNNN: <título en pocas palabras, en modo decisión>

## Estado

Propuesta | Aceptada | Reemplazada por ADR-XXXX | Obsoleta — AAAA-MM-DD

## Contexto

¿Qué problema o fuerza nos obliga a decidir algo? Describe la situación sin
todavía justificar la decisión: restricciones técnicas, de negocio, de
plazo o de equipo que empujan hacia una u otra opción.

## Decisión

Qué se decidió, en una o dos frases directas ("Usaremos X para Y").

## Consecuencias

### Positivas

-

### Negativas / trade-offs

-

## Alternativas consideradas

- **Opción descartada A** — por qué no.
- **Opción descartada B** — por qué no, o bajo qué condición futura sí.
